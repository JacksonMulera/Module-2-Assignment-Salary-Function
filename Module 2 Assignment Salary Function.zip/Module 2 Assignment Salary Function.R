# loading utils package

library(utils)

# Specify the path to the zip file 

zip_file_path <- 'D:/Accounts/Social Media/MSBA Nexford/Programming in R & Python/Module 2 Assignment Salary Function/Employee Profiles.zip'

# Specify the destination folder for extraction
extracted_folder <- 'D:/Accounts/Social Media/MSBA Nexford/Programming in R & Python/Module 2 Assignment Salary Function/'

# Unzip the file using the utils library
utils::unzip(zip_file_path, exdir = extracted_folder)

print('Files extracted successfully.\n')
