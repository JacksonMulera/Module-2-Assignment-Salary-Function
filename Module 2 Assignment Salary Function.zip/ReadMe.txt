
Instructions on how to Run the Codes

	1. Python Code
	-Run the code saved under Module 2 Assignment Salary Function using Jupyter Note book.

	2. R
	-Run the code saved under Module 2 Assignment Salary Function using R Studio.

  	3. The link to Github is:
	
	https://github.com/JacksonMulera/Module-2-Assignment-Salary-Function	

	Thanks.